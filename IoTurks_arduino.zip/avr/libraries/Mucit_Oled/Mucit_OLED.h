
#ifndef Mucit_OLED_data_H
#define Mucit_OLED_data_H
 #define WIRE_WRITE Wire.write
#include "Arduino.h"

#define Mucit_OLED_Command_Mode            0x80
#define Mucit_OLED_Data_Mode            0x40

#define Set_Contrast_Cmd                      0x81
    

#define Entire_Display_On_Resume_Cmd          0xA4    
 
#define Entire_Display_On_Cmd                 0xA5     
#define Mucit_OLED_Normal_Display_Cmd         0xA6     
#define Mucit_OLED_Inverse_Display_Cmd         0xA7    
#define Mucit_OLED_Display_Off_Cmd         0xAE     
#define Mucit_OLED_Display_On_Cmd         0xAF     
#define Right_Horizontal_Scroll_Cmd           0x26
#define Left_Horizontal_Scroll_Cmd            0x27
#define Vertical_Right_Horizontal_Scroll_Cmd  0x29
#define Vertical_Left_Horizontal_Scroll_Cmd   0x2A
#define Activate_Scroll_Cmd                   0x2F
#define Deactivate_Scroll_Cmd                 0x2E

#define Set_Vertical_Scroll_Area_Cmd          0xA3
#define Set_Memory_Addressing_Mode_Cmd        0x20
#define HORIZONTAL_MODE               0x00
#define VERTICAL_MODE               0x01
#define PAGE_MODE               0x02       
#define Set_Column_Address_Cmd                0x21      
#define Set_Page_Address_Cmd                  0x22       
#define Segment_Remap_Cmd                     0xA1       
#define Segment_Normal_map_Cmd                0xA0       
#define Set_Multiplex_Ratio_Cmd               0xA8       
#define COM_Output_Normal_Scan_Cmd            0xC0     
#define COM_Output_Remap_Scan_Cmd             0xC8       
#define Set_Display_Offset_Cmd                0xD3       
#define Set_COM_Pins_Hardware_Config_Cmd      0xDA   
#define Set_Display_Clock_Divide_Ratio_Cmd    0xD5
#define Set_Precharge_Period_Cmd              0xD9
#define Set_VCOMH_Deselect_Level_Cmd          0xDB
#define No_Operation_Cmd                      0xE3
#define Charge_Pump_Setting_Cmd               0x8D
#define Charge_Pump_Enable_Cmd                 0x14
#define Charge_Pump_Disable_Cmd               0x10    
#define Scroll_Left               0x00
#define Scroll_Right               0x01
#define Scroll_2Frames               0x7
#define Scroll_3Frames               0x4
#define Scroll_4Frames               0x5
#define Scroll_5Frames               0x0
#define Scroll_25Frames               0x6
#define Scroll_64Frames               0x1
#define Scroll_128Frames            0x2
#define Scroll_256Frames            0x3
#define Dummy_Byte_0x00                       0x00
#define Dummy_Byte_0xFF                       0xFF


#define swap(a, b) { uint8_t t = a; a = b; b = t; }

class Mucit_OLED : public  Print{
public:

void constructor(uint8_t w, uint8_t h);

void baslat();

void setNormalDisplay();
void setInverseDisplay();
void sendCommand(unsigned char command);
void sendData(unsigned char Data);

void setPageMode();
void setHorizontalMode();
void setVerticalMode();

void goster();
void temizle();
void clearArea(uint8_t x, uint8_t y, uint8_t w, uint8_t h);

void drawPixel(int8_t x, int8_t y, uint8_t color);
void drawChar(int8_t x, int8_t y, unsigned char c, int8_t color, int8_t bg, uint8_t size);
void resimCiz(uint8_t x, uint8_t y, const uint8_t *bitmap, uint8_t w, uint8_t h, uint8_t color);

void setBrightness(unsigned char Brightness);
void yaziBoyutu(uint8_t s);
void baslangicNoktasi(uint8_t x, uint8_t y);
void yaziRengi(uint8_t c);
void yaziRengi(uint8_t c, uint8_t bg);
void setTextWrap(boolean w);

void drawRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t color);
void fillRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t color);
void drawFastHLine(uint8_t x, uint8_t y, uint8_t w, uint8_t color);
void drawFastVLine(uint8_t x, uint8_t y, uint8_t h, uint8_t color);
void drawLine(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1, uint8_t color);

void drawTriangle(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t color);
void fillTriangle(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t color);
void drawRoundRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t radius, uint8_t color);
void fillRoundRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t radius, uint8_t color);

void drawCircle(uint8_t x0, uint8_t y0, uint8_t r, uint8_t color);
void drawCircleHelper(uint8_t x0, uint8_t y0, uint8_t r, uint8_t cornername, uint8_t color);
void fillCircle(uint8_t x0, uint8_t y0, uint8_t r, uint8_t color);
void fillCircleHelper(uint8_t x0, uint8_t y0, uint8_t r, uint8_t cornername, int16_t delta, uint8_t color);

void setHorizontalScrollProperties(bool direction,unsigned char startPage, unsigned char endPage, unsigned char scrollSpeed);
void activateScroll();
void deactivateScroll();

uint8_t height(void);
uint8_t width(void);

void setRotation(uint8_t r);
uint8_t getRotation(void);



  virtual size_t write(uint8_t);


protected:

uint8_t SlaveAddress;                  
uint8_t  WIDTH, HEIGHT;   
uint8_t  _width, _height; 
uint8_t  cursor_x, cursor_y;
uint8_t  textcolor, textbgcolor;
uint8_t  textsize;
uint8_t  rotation;
boolean  wrap; 

};

#endif



